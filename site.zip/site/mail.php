<?php

$nombre =$_POST['nombre'];
$email =$_POST['correo'];
$asunto ='Formulario Rellenado';
$mensaje ="Nombre:".$nombre."<br> Email: $email<br>
Mensaje:".$_POST['mensaje'];

if(mail('jonathancortesperez937@gmail.com',$asunto,$mensaje)){
  echo "Correo enviado";
}
?>